﻿namespace Bank_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnBankRestore = new System.Windows.Forms.Button();
            this.dataBank = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.lblBankMessage = new System.Windows.Forms.RichTextBox();
            this.btnBankDelete = new System.Windows.Forms.Button();
            this.btnBankInsert = new System.Windows.Forms.Button();
            this.btnBankUpdate = new System.Windows.Forms.Button();
            this.txtBankDeleteV = new System.Windows.Forms.TextBox();
            this.txtBankDeleteO = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBankDeleteP = new System.Windows.Forms.ComboBox();
            this.txtBankUpdateV2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBankUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBankUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtBankUpdateO = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBankUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBankAddress = new System.Windows.Forms.TextBox();
            this.txtBankBankName = new System.Windows.Forms.TextBox();
            this.txtBankBankCode = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnBranchRestore = new System.Windows.Forms.Button();
            this.dataBranch = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.lblBranchMessage = new System.Windows.Forms.RichTextBox();
            this.btnBranchDelete = new System.Windows.Forms.Button();
            this.btnBranchInsert = new System.Windows.Forms.Button();
            this.btnBranchUpdate = new System.Windows.Forms.Button();
            this.txtBranchDeleteV = new System.Windows.Forms.TextBox();
            this.txtBranchDeleteO = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBranchDeleteP = new System.Windows.Forms.ComboBox();
            this.txtBranchUpdateV2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBranchUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBranchUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtBranchUpdateO = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBranchUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtBranchAddress = new System.Windows.Forms.TextBox();
            this.txtBranchBranchNumber = new System.Windows.Forms.TextBox();
            this.txtBranchBankCode = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label57 = new System.Windows.Forms.Label();
            this.txtLoanLoanType = new System.Windows.Forms.TextBox();
            this.btnLoanRestore = new System.Windows.Forms.Button();
            this.dataLoan = new System.Windows.Forms.DataGridView();
            this.label17 = new System.Windows.Forms.Label();
            this.lblLoanMessage = new System.Windows.Forms.RichTextBox();
            this.btnLoanDelete = new System.Windows.Forms.Button();
            this.btnLoanInsert = new System.Windows.Forms.Button();
            this.btnLoanUpdate = new System.Windows.Forms.Button();
            this.txtLoanDeleteV = new System.Windows.Forms.TextBox();
            this.txtLoanDeleteO = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtLoanDeleteP = new System.Windows.Forms.ComboBox();
            this.txtLoanUpdateV2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtLoanUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtLoanUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtLoanUpdateO = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtLoanUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtLoanLoanNumber = new System.Windows.Forms.TextBox();
            this.txtLoanBranchNumber = new System.Windows.Forms.TextBox();
            this.txtLoanBankCode = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label27 = new System.Windows.Forms.Label();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.btnCustomerDelete = new System.Windows.Forms.Button();
            this.btnCustomerInsert = new System.Windows.Forms.Button();
            this.btnCustomerUpdate = new System.Windows.Forms.Button();
            this.txtCustomerDeleteV = new System.Windows.Forms.TextBox();
            this.txtCustomerDeleteO = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtCustomerDeleteP = new System.Windows.Forms.ComboBox();
            this.txtCustomerUpdateV2 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtCustomerUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtCustomerUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtCustomerUpdateO = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtCustomerUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.txtCustomerPhone = new System.Windows.Forms.TextBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtCustomerSSN = new System.Windows.Forms.TextBox();
            this.btnCustomerRestore = new System.Windows.Forms.Button();
            this.dataCustomer = new System.Windows.Forms.DataGridView();
            this.label25 = new System.Windows.Forms.Label();
            this.lblCustomerMessage = new System.Windows.Forms.RichTextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label35 = new System.Windows.Forms.Label();
            this.txtAccountBalance = new System.Windows.Forms.TextBox();
            this.btnAccountDelete = new System.Windows.Forms.Button();
            this.btnAccountInsert = new System.Windows.Forms.Button();
            this.btnAccountUpdate = new System.Windows.Forms.Button();
            this.txtAccountDeleteV = new System.Windows.Forms.TextBox();
            this.txtAccountDeleteO = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtAccountDeleteP = new System.Windows.Forms.ComboBox();
            this.txtAccountUpdateV2 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtAccountUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtAccountUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtAccountUpdateO = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtAccountUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.txtAccountType = new System.Windows.Forms.TextBox();
            this.txtAccountSSN = new System.Windows.Forms.TextBox();
            this.txtAccountNumber = new System.Windows.Forms.TextBox();
            this.btnAccountRestore = new System.Windows.Forms.Button();
            this.dataAccount = new System.Windows.Forms.DataGridView();
            this.label33 = new System.Windows.Forms.Label();
            this.lblAccountMessage = new System.Windows.Forms.RichTextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.txtBorrowsStartDate = new System.Windows.Forms.TextBox();
            this.txtBorrowsAmount = new System.Windows.Forms.TextBox();
            this.txtBorrowsSSN = new System.Windows.Forms.TextBox();
            this.btnBorrowRestore = new System.Windows.Forms.Button();
            this.dataBorrows = new System.Windows.Forms.DataGridView();
            this.label41 = new System.Windows.Forms.Label();
            this.lblBorrowsMessage = new System.Windows.Forms.RichTextBox();
            this.btnBorrowsDelete = new System.Windows.Forms.Button();
            this.btnBorrowsInsert = new System.Windows.Forms.Button();
            this.btnBorrowsUpdate = new System.Windows.Forms.Button();
            this.txtBorrowsDeleteV = new System.Windows.Forms.TextBox();
            this.txtBorrowsDeleteO = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtBorrowsDeleteP = new System.Windows.Forms.ComboBox();
            this.txtBorrowsUpdateV2 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtBorrowsUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtBorrowsUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtBorrowsUpdateO = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtBorrowsUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtBorrowsLoanNumber = new System.Windows.Forms.TextBox();
            this.txtBorrowsBranchNumber = new System.Windows.Forms.TextBox();
            this.txtBorrowsBankCode = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.btnHasRestore = new System.Windows.Forms.Button();
            this.dataHas = new System.Windows.Forms.DataGridView();
            this.label49 = new System.Windows.Forms.Label();
            this.lblHasMessage = new System.Windows.Forms.RichTextBox();
            this.btnHasDelete = new System.Windows.Forms.Button();
            this.btnHasInsert = new System.Windows.Forms.Button();
            this.btnHasUpdate = new System.Windows.Forms.Button();
            this.txtHasDeleteV = new System.Windows.Forms.TextBox();
            this.txtHasDeleteO = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtHasDeleteP = new System.Windows.Forms.ComboBox();
            this.txtHasUpdateV2 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtHasUpdateP2 = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtHasUpdateV1 = new System.Windows.Forms.TextBox();
            this.txtHasUpdateO = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtHasUpdateP1 = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.txtHasSSN = new System.Windows.Forms.TextBox();
            this.txtHasBranchNumber = new System.Windows.Forms.TextBox();
            this.txtHasBankCode = new System.Windows.Forms.TextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.btnReportsHighestLoans = new System.Windows.Forms.Button();
            this.btnReportsEarliestLoans = new System.Windows.Forms.Button();
            this.btnReportsTotalLoan = new System.Windows.Forms.Button();
            this.btnReportsNumOfCustomers = new System.Windows.Forms.Button();
            this.btnReportsRichestCustomers = new System.Windows.Forms.Button();
            this.btnReportsMostBorrowed = new System.Windows.Forms.Button();
            this.dataReports = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBank)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBranch)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataLoan)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCustomer)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataAccount)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBorrows)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataHas)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataReports)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1395, 687);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnBankRestore);
            this.tabPage1.Controls.Add(this.dataBank);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.lblBankMessage);
            this.tabPage1.Controls.Add(this.btnBankDelete);
            this.tabPage1.Controls.Add(this.btnBankInsert);
            this.tabPage1.Controls.Add(this.btnBankUpdate);
            this.tabPage1.Controls.Add(this.txtBankDeleteV);
            this.tabPage1.Controls.Add(this.txtBankDeleteO);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtBankDeleteP);
            this.tabPage1.Controls.Add(this.txtBankUpdateV2);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtBankUpdateP2);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtBankUpdateV1);
            this.tabPage1.Controls.Add(this.txtBankUpdateO);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtBankUpdateP1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtBankAddress);
            this.tabPage1.Controls.Add(this.txtBankBankName);
            this.tabPage1.Controls.Add(this.txtBankBankCode);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1387, 658);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Bank";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnBankRestore
            // 
            this.btnBankRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBankRestore.Location = new System.Drawing.Point(854, 608);
            this.btnBankRestore.Name = "btnBankRestore";
            this.btnBankRestore.Size = new System.Drawing.Size(255, 39);
            this.btnBankRestore.TabIndex = 24;
            this.btnBankRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnBankRestore.UseVisualStyleBackColor = true;
            this.btnBankRestore.Click += new System.EventHandler(this.btnBankRestore_Click);
            // 
            // dataBank
            // 
            this.dataBank.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataBank.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataBank.Location = new System.Drawing.Point(600, 6);
            this.dataBank.Name = "dataBank";
            this.dataBank.ReadOnly = true;
            this.dataBank.Size = new System.Drawing.Size(776, 589);
            this.dataBank.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(49, 382);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 17);
            this.label8.TabIndex = 22;
            this.label8.Text = "System Messages";
            // 
            // lblBankMessage
            // 
            this.lblBankMessage.Location = new System.Drawing.Point(49, 402);
            this.lblBankMessage.Name = "lblBankMessage";
            this.lblBankMessage.ReadOnly = true;
            this.lblBankMessage.Size = new System.Drawing.Size(509, 239);
            this.lblBankMessage.TabIndex = 21;
            this.lblBankMessage.Text = "";
            // 
            // btnBankDelete
            // 
            this.btnBankDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBankDelete.Location = new System.Drawing.Point(234, 326);
            this.btnBankDelete.Name = "btnBankDelete";
            this.btnBankDelete.Size = new System.Drawing.Size(77, 29);
            this.btnBankDelete.TabIndex = 20;
            this.btnBankDelete.Text = "Delete";
            this.btnBankDelete.UseVisualStyleBackColor = true;
            this.btnBankDelete.Click += new System.EventHandler(this.btnBankDelete_Click);
            // 
            // btnBankInsert
            // 
            this.btnBankInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBankInsert.Location = new System.Drawing.Point(113, 176);
            this.btnBankInsert.Name = "btnBankInsert";
            this.btnBankInsert.Size = new System.Drawing.Size(77, 29);
            this.btnBankInsert.TabIndex = 19;
            this.btnBankInsert.Text = "Insert";
            this.btnBankInsert.UseVisualStyleBackColor = true;
            this.btnBankInsert.Click += new System.EventHandler(this.btnBankInsert_Click);
            // 
            // btnBankUpdate
            // 
            this.btnBankUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBankUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnBankUpdate.Name = "btnBankUpdate";
            this.btnBankUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnBankUpdate.TabIndex = 18;
            this.btnBankUpdate.Text = "Update";
            this.btnBankUpdate.UseVisualStyleBackColor = true;
            this.btnBankUpdate.Click += new System.EventHandler(this.btnBankUpdate_Click);
            // 
            // txtBankDeleteV
            // 
            this.txtBankDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankDeleteV.Location = new System.Drawing.Point(301, 282);
            this.txtBankDeleteV.Name = "txtBankDeleteV";
            this.txtBankDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtBankDeleteV.TabIndex = 17;
            this.txtBankDeleteV.Text = "1";
            // 
            // txtBankDeleteO
            // 
            this.txtBankDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBankDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankDeleteO.FormattingEnabled = true;
            this.txtBankDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtBankDeleteO.Location = new System.Drawing.Point(260, 282);
            this.txtBankDeleteO.Name = "txtBankDeleteO";
            this.txtBankDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtBankDeleteO.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(142, 262);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(174, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Delete each bank that has";
            // 
            // txtBankDeleteP
            // 
            this.txtBankDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBankDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBankDeleteP.FormattingEnabled = true;
            this.txtBankDeleteP.Items.AddRange(new object[] {
            "BANKCODE",
            "NAME",
            "ADDRESS"});
            this.txtBankDeleteP.Location = new System.Drawing.Point(145, 282);
            this.txtBankDeleteP.Name = "txtBankDeleteP";
            this.txtBankDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtBankDeleteP.TabIndex = 14;
            // 
            // txtBankUpdateV2
            // 
            this.txtBankUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtBankUpdateV2.Name = "txtBankUpdateV2";
            this.txtBankUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtBankUpdateV2.TabIndex = 13;
            this.txtBankUpdateV2.Text = "Giza";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(300, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "to this new value:";
            // 
            // txtBankUpdateP2
            // 
            this.txtBankUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBankUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBankUpdateP2.FormattingEnabled = true;
            this.txtBankUpdateP2.Items.AddRange(new object[] {
            "BANKCODE",
            "NAME",
            "ADDRESS"});
            this.txtBankUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtBankUpdateP2.Name = "txtBankUpdateP2";
            this.txtBankUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtBankUpdateP2.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(300, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Change the value of";
            // 
            // txtBankUpdateV1
            // 
            this.txtBankUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtBankUpdateV1.Name = "txtBankUpdateV1";
            this.txtBankUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtBankUpdateV1.TabIndex = 9;
            this.txtBankUpdateV1.Text = "1";
            // 
            // txtBankUpdateO
            // 
            this.txtBankUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBankUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankUpdateO.FormattingEnabled = true;
            this.txtBankUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtBankUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtBankUpdateO.Name = "txtBankUpdateO";
            this.txtBankUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtBankUpdateO.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(300, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "For each bank that has";
            // 
            // txtBankUpdateP1
            // 
            this.txtBankUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBankUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBankUpdateP1.FormattingEnabled = true;
            this.txtBankUpdateP1.Items.AddRange(new object[] {
            "BANKCODE",
            "NAME",
            "ADDRESS"});
            this.txtBankUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtBankUpdateP1.Name = "txtBankUpdateP1";
            this.txtBankUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtBankUpdateP1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Bank Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bank Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Bank Code";
            // 
            // txtBankAddress
            // 
            this.txtBankAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankAddress.Location = new System.Drawing.Point(132, 129);
            this.txtBankAddress.Name = "txtBankAddress";
            this.txtBankAddress.Size = new System.Drawing.Size(100, 23);
            this.txtBankAddress.TabIndex = 2;
            // 
            // txtBankBankName
            // 
            this.txtBankBankName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankBankName.Location = new System.Drawing.Point(132, 79);
            this.txtBankBankName.Name = "txtBankBankName";
            this.txtBankBankName.Size = new System.Drawing.Size(100, 23);
            this.txtBankBankName.TabIndex = 1;
            // 
            // txtBankBankCode
            // 
            this.txtBankBankCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankBankCode.Location = new System.Drawing.Point(132, 34);
            this.txtBankBankCode.Name = "txtBankBankCode";
            this.txtBankBankCode.Size = new System.Drawing.Size(100, 23);
            this.txtBankBankCode.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnBranchRestore);
            this.tabPage2.Controls.Add(this.dataBranch);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.lblBranchMessage);
            this.tabPage2.Controls.Add(this.btnBranchDelete);
            this.tabPage2.Controls.Add(this.btnBranchInsert);
            this.tabPage2.Controls.Add(this.btnBranchUpdate);
            this.tabPage2.Controls.Add(this.txtBranchDeleteV);
            this.tabPage2.Controls.Add(this.txtBranchDeleteO);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.txtBranchDeleteP);
            this.tabPage2.Controls.Add(this.txtBranchUpdateV2);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.txtBranchUpdateP2);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtBranchUpdateV1);
            this.tabPage2.Controls.Add(this.txtBranchUpdateO);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.txtBranchUpdateP1);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.txtBranchAddress);
            this.tabPage2.Controls.Add(this.txtBranchBranchNumber);
            this.tabPage2.Controls.Add(this.txtBranchBankCode);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1387, 658);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Branch";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnBranchRestore
            // 
            this.btnBranchRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranchRestore.Location = new System.Drawing.Point(854, 608);
            this.btnBranchRestore.Name = "btnBranchRestore";
            this.btnBranchRestore.Size = new System.Drawing.Size(255, 39);
            this.btnBranchRestore.TabIndex = 49;
            this.btnBranchRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnBranchRestore.UseVisualStyleBackColor = true;
            this.btnBranchRestore.Click += new System.EventHandler(this.btnBranchRestore_Click);
            // 
            // dataBranch
            // 
            this.dataBranch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataBranch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataBranch.Location = new System.Drawing.Point(600, 6);
            this.dataBranch.Name = "dataBranch";
            this.dataBranch.ReadOnly = true;
            this.dataBranch.Size = new System.Drawing.Size(776, 589);
            this.dataBranch.TabIndex = 48;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(49, 382);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 17);
            this.label9.TabIndex = 47;
            this.label9.Text = "System Messages";
            // 
            // lblBranchMessage
            // 
            this.lblBranchMessage.Location = new System.Drawing.Point(49, 402);
            this.lblBranchMessage.Name = "lblBranchMessage";
            this.lblBranchMessage.ReadOnly = true;
            this.lblBranchMessage.Size = new System.Drawing.Size(509, 239);
            this.lblBranchMessage.TabIndex = 46;
            this.lblBranchMessage.Text = "";
            // 
            // btnBranchDelete
            // 
            this.btnBranchDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranchDelete.Location = new System.Drawing.Point(234, 326);
            this.btnBranchDelete.Name = "btnBranchDelete";
            this.btnBranchDelete.Size = new System.Drawing.Size(77, 29);
            this.btnBranchDelete.TabIndex = 45;
            this.btnBranchDelete.Text = "Delete";
            this.btnBranchDelete.UseVisualStyleBackColor = true;
            this.btnBranchDelete.Click += new System.EventHandler(this.btnBranchDelete_Click);
            // 
            // btnBranchInsert
            // 
            this.btnBranchInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranchInsert.Location = new System.Drawing.Point(113, 176);
            this.btnBranchInsert.Name = "btnBranchInsert";
            this.btnBranchInsert.Size = new System.Drawing.Size(77, 29);
            this.btnBranchInsert.TabIndex = 44;
            this.btnBranchInsert.Text = "Insert";
            this.btnBranchInsert.UseVisualStyleBackColor = true;
            this.btnBranchInsert.Click += new System.EventHandler(this.btnBranchInsert_Click);
            // 
            // btnBranchUpdate
            // 
            this.btnBranchUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranchUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnBranchUpdate.Name = "btnBranchUpdate";
            this.btnBranchUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnBranchUpdate.TabIndex = 43;
            this.btnBranchUpdate.Text = "Update";
            this.btnBranchUpdate.UseVisualStyleBackColor = true;
            this.btnBranchUpdate.Click += new System.EventHandler(this.btnBranchUpdate_Click);
            // 
            // txtBranchDeleteV
            // 
            this.txtBranchDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchDeleteV.Location = new System.Drawing.Point(301, 282);
            this.txtBranchDeleteV.Name = "txtBranchDeleteV";
            this.txtBranchDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtBranchDeleteV.TabIndex = 42;
            // 
            // txtBranchDeleteO
            // 
            this.txtBranchDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBranchDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchDeleteO.FormattingEnabled = true;
            this.txtBranchDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtBranchDeleteO.Location = new System.Drawing.Point(260, 282);
            this.txtBranchDeleteO.Name = "txtBranchDeleteO";
            this.txtBranchDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtBranchDeleteO.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(142, 262);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(187, 17);
            this.label10.TabIndex = 40;
            this.label10.Text = "Delete each branch that has";
            // 
            // txtBranchDeleteP
            // 
            this.txtBranchDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBranchDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBranchDeleteP.FormattingEnabled = true;
            this.txtBranchDeleteP.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "ADDRESS"});
            this.txtBranchDeleteP.Location = new System.Drawing.Point(145, 282);
            this.txtBranchDeleteP.Name = "txtBranchDeleteP";
            this.txtBranchDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtBranchDeleteP.TabIndex = 39;
            // 
            // txtBranchUpdateV2
            // 
            this.txtBranchUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtBranchUpdateV2.Name = "txtBranchUpdateV2";
            this.txtBranchUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtBranchUpdateV2.TabIndex = 38;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(300, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 17);
            this.label11.TabIndex = 37;
            this.label11.Text = "to this new value:";
            // 
            // txtBranchUpdateP2
            // 
            this.txtBranchUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBranchUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBranchUpdateP2.FormattingEnabled = true;
            this.txtBranchUpdateP2.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "ADDRESS"});
            this.txtBranchUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtBranchUpdateP2.Name = "txtBranchUpdateP2";
            this.txtBranchUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtBranchUpdateP2.TabIndex = 36;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(300, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 17);
            this.label12.TabIndex = 35;
            this.label12.Text = "Change the value of";
            // 
            // txtBranchUpdateV1
            // 
            this.txtBranchUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtBranchUpdateV1.Name = "txtBranchUpdateV1";
            this.txtBranchUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtBranchUpdateV1.TabIndex = 34;
            // 
            // txtBranchUpdateO
            // 
            this.txtBranchUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBranchUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchUpdateO.FormattingEnabled = true;
            this.txtBranchUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtBranchUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtBranchUpdateO.Name = "txtBranchUpdateO";
            this.txtBranchUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtBranchUpdateO.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(300, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(167, 17);
            this.label13.TabIndex = 32;
            this.label13.Text = "For each branch that has";
            // 
            // txtBranchUpdateP1
            // 
            this.txtBranchUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBranchUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchUpdateP1.FormattingEnabled = true;
            this.txtBranchUpdateP1.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "ADDRESS"});
            this.txtBranchUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtBranchUpdateP1.Name = "txtBranchUpdateP1";
            this.txtBranchUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtBranchUpdateP1.TabIndex = 31;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(19, 129);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 17);
            this.label14.TabIndex = 30;
            this.label14.Text = "Branch Address";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(21, 82);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 17);
            this.label15.TabIndex = 29;
            this.label15.Text = "Branch Number";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(51, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 17);
            this.label16.TabIndex = 28;
            this.label16.Text = "Bank Code";
            // 
            // txtBranchAddress
            // 
            this.txtBranchAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchAddress.Location = new System.Drawing.Point(132, 129);
            this.txtBranchAddress.Name = "txtBranchAddress";
            this.txtBranchAddress.Size = new System.Drawing.Size(100, 23);
            this.txtBranchAddress.TabIndex = 27;
            // 
            // txtBranchBranchNumber
            // 
            this.txtBranchBranchNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchBranchNumber.Location = new System.Drawing.Point(132, 79);
            this.txtBranchBranchNumber.Name = "txtBranchBranchNumber";
            this.txtBranchBranchNumber.Size = new System.Drawing.Size(100, 23);
            this.txtBranchBranchNumber.TabIndex = 26;
            // 
            // txtBranchBankCode
            // 
            this.txtBranchBankCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBranchBankCode.Location = new System.Drawing.Point(132, 34);
            this.txtBranchBankCode.Name = "txtBranchBankCode";
            this.txtBranchBankCode.Size = new System.Drawing.Size(100, 23);
            this.txtBranchBankCode.TabIndex = 25;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label57);
            this.tabPage3.Controls.Add(this.txtLoanLoanType);
            this.tabPage3.Controls.Add(this.btnLoanRestore);
            this.tabPage3.Controls.Add(this.dataLoan);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.lblLoanMessage);
            this.tabPage3.Controls.Add(this.btnLoanDelete);
            this.tabPage3.Controls.Add(this.btnLoanInsert);
            this.tabPage3.Controls.Add(this.btnLoanUpdate);
            this.tabPage3.Controls.Add(this.txtLoanDeleteV);
            this.tabPage3.Controls.Add(this.txtLoanDeleteO);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.txtLoanDeleteP);
            this.tabPage3.Controls.Add(this.txtLoanUpdateV2);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.txtLoanUpdateP2);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.txtLoanUpdateV1);
            this.tabPage3.Controls.Add(this.txtLoanUpdateO);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.txtLoanUpdateP1);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.txtLoanLoanNumber);
            this.tabPage3.Controls.Add(this.txtLoanBranchNumber);
            this.tabPage3.Controls.Add(this.txtLoanBankCode);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1387, 658);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Loan";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(46, 204);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(76, 17);
            this.label57.TabIndex = 51;
            this.label57.Text = "Loan Type";
            // 
            // txtLoanLoanType
            // 
            this.txtLoanLoanType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanLoanType.Location = new System.Drawing.Point(132, 204);
            this.txtLoanLoanType.Name = "txtLoanLoanType";
            this.txtLoanLoanType.Size = new System.Drawing.Size(100, 23);
            this.txtLoanLoanType.TabIndex = 50;
            // 
            // btnLoanRestore
            // 
            this.btnLoanRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoanRestore.Location = new System.Drawing.Point(854, 608);
            this.btnLoanRestore.Name = "btnLoanRestore";
            this.btnLoanRestore.Size = new System.Drawing.Size(255, 39);
            this.btnLoanRestore.TabIndex = 49;
            this.btnLoanRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnLoanRestore.UseVisualStyleBackColor = true;
            this.btnLoanRestore.Click += new System.EventHandler(this.btnLoanRestore_Click);
            // 
            // dataLoan
            // 
            this.dataLoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataLoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataLoan.Location = new System.Drawing.Point(600, 6);
            this.dataLoan.Name = "dataLoan";
            this.dataLoan.ReadOnly = true;
            this.dataLoan.Size = new System.Drawing.Size(776, 589);
            this.dataLoan.TabIndex = 48;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(49, 382);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(122, 17);
            this.label17.TabIndex = 47;
            this.label17.Text = "System Messages";
            // 
            // lblLoanMessage
            // 
            this.lblLoanMessage.Location = new System.Drawing.Point(49, 402);
            this.lblLoanMessage.Name = "lblLoanMessage";
            this.lblLoanMessage.ReadOnly = true;
            this.lblLoanMessage.Size = new System.Drawing.Size(509, 239);
            this.lblLoanMessage.TabIndex = 46;
            this.lblLoanMessage.Text = "";
            // 
            // btnLoanDelete
            // 
            this.btnLoanDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoanDelete.Location = new System.Drawing.Point(377, 327);
            this.btnLoanDelete.Name = "btnLoanDelete";
            this.btnLoanDelete.Size = new System.Drawing.Size(77, 29);
            this.btnLoanDelete.TabIndex = 45;
            this.btnLoanDelete.Text = "Delete";
            this.btnLoanDelete.UseVisualStyleBackColor = true;
            this.btnLoanDelete.Click += new System.EventHandler(this.btnLoanDelete_Click);
            // 
            // btnLoanInsert
            // 
            this.btnLoanInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoanInsert.Location = new System.Drawing.Point(112, 252);
            this.btnLoanInsert.Name = "btnLoanInsert";
            this.btnLoanInsert.Size = new System.Drawing.Size(77, 29);
            this.btnLoanInsert.TabIndex = 44;
            this.btnLoanInsert.Text = "Insert";
            this.btnLoanInsert.UseVisualStyleBackColor = true;
            this.btnLoanInsert.Click += new System.EventHandler(this.btnLoanInsert_Click);
            // 
            // btnLoanUpdate
            // 
            this.btnLoanUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoanUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnLoanUpdate.Name = "btnLoanUpdate";
            this.btnLoanUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnLoanUpdate.TabIndex = 43;
            this.btnLoanUpdate.Text = "Update";
            this.btnLoanUpdate.UseVisualStyleBackColor = true;
            this.btnLoanUpdate.Click += new System.EventHandler(this.btnLoanUpdate_Click);
            // 
            // txtLoanDeleteV
            // 
            this.txtLoanDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanDeleteV.Location = new System.Drawing.Point(444, 283);
            this.txtLoanDeleteV.Name = "txtLoanDeleteV";
            this.txtLoanDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtLoanDeleteV.TabIndex = 42;
            // 
            // txtLoanDeleteO
            // 
            this.txtLoanDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtLoanDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanDeleteO.FormattingEnabled = true;
            this.txtLoanDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtLoanDeleteO.Location = new System.Drawing.Point(403, 283);
            this.txtLoanDeleteO.Name = "txtLoanDeleteO";
            this.txtLoanDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtLoanDeleteO.TabIndex = 41;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(285, 263);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(170, 17);
            this.label18.TabIndex = 40;
            this.label18.Text = "Delete each loan that has";
            // 
            // txtLoanDeleteP
            // 
            this.txtLoanDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtLoanDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtLoanDeleteP.FormattingEnabled = true;
            this.txtLoanDeleteP.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "LOANNUMBER",
            "TYPE"});
            this.txtLoanDeleteP.Location = new System.Drawing.Point(288, 283);
            this.txtLoanDeleteP.Name = "txtLoanDeleteP";
            this.txtLoanDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtLoanDeleteP.TabIndex = 39;
            // 
            // txtLoanUpdateV2
            // 
            this.txtLoanUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtLoanUpdateV2.Name = "txtLoanUpdateV2";
            this.txtLoanUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtLoanUpdateV2.TabIndex = 38;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(300, 126);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(117, 17);
            this.label19.TabIndex = 37;
            this.label19.Text = "to this new value:";
            // 
            // txtLoanUpdateP2
            // 
            this.txtLoanUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtLoanUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtLoanUpdateP2.FormattingEnabled = true;
            this.txtLoanUpdateP2.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "LOANNUMBER",
            "TYPE"});
            this.txtLoanUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtLoanUpdateP2.Name = "txtLoanUpdateP2";
            this.txtLoanUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtLoanUpdateP2.TabIndex = 36;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(300, 88);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(135, 17);
            this.label20.TabIndex = 35;
            this.label20.Text = "Change the value of";
            // 
            // txtLoanUpdateV1
            // 
            this.txtLoanUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtLoanUpdateV1.Name = "txtLoanUpdateV1";
            this.txtLoanUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtLoanUpdateV1.TabIndex = 34;
            // 
            // txtLoanUpdateO
            // 
            this.txtLoanUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtLoanUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanUpdateO.FormattingEnabled = true;
            this.txtLoanUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtLoanUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtLoanUpdateO.Name = "txtLoanUpdateO";
            this.txtLoanUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtLoanUpdateO.TabIndex = 33;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(300, 32);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(150, 17);
            this.label21.TabIndex = 32;
            this.label21.Text = "For each loan that has";
            // 
            // txtLoanUpdateP1
            // 
            this.txtLoanUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtLoanUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtLoanUpdateP1.FormattingEnabled = true;
            this.txtLoanUpdateP1.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "LOANNUMBER",
            "TYPE"});
            this.txtLoanUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtLoanUpdateP1.Name = "txtLoanUpdateP1";
            this.txtLoanUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtLoanUpdateP1.TabIndex = 31;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(30, 145);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(94, 17);
            this.label22.TabIndex = 30;
            this.label22.Text = "Loan Number";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(19, 91);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(107, 17);
            this.label23.TabIndex = 29;
            this.label23.Text = "Branch Number";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(49, 37);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 17);
            this.label24.TabIndex = 28;
            this.label24.Text = "Bank Code";
            // 
            // txtLoanLoanNumber
            // 
            this.txtLoanLoanNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanLoanNumber.Location = new System.Drawing.Point(132, 145);
            this.txtLoanLoanNumber.Name = "txtLoanLoanNumber";
            this.txtLoanLoanNumber.Size = new System.Drawing.Size(100, 23);
            this.txtLoanLoanNumber.TabIndex = 27;
            // 
            // txtLoanBranchNumber
            // 
            this.txtLoanBranchNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanBranchNumber.Location = new System.Drawing.Point(132, 88);
            this.txtLoanBranchNumber.Name = "txtLoanBranchNumber";
            this.txtLoanBranchNumber.Size = new System.Drawing.Size(100, 23);
            this.txtLoanBranchNumber.TabIndex = 26;
            // 
            // txtLoanBankCode
            // 
            this.txtLoanBankCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanBankCode.Location = new System.Drawing.Point(132, 34);
            this.txtLoanBankCode.Name = "txtLoanBankCode";
            this.txtLoanBankCode.Size = new System.Drawing.Size(100, 23);
            this.txtLoanBankCode.TabIndex = 25;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label27);
            this.tabPage4.Controls.Add(this.txtCustomerAddress);
            this.tabPage4.Controls.Add(this.btnCustomerDelete);
            this.tabPage4.Controls.Add(this.btnCustomerInsert);
            this.tabPage4.Controls.Add(this.btnCustomerUpdate);
            this.tabPage4.Controls.Add(this.txtCustomerDeleteV);
            this.tabPage4.Controls.Add(this.txtCustomerDeleteO);
            this.tabPage4.Controls.Add(this.label28);
            this.tabPage4.Controls.Add(this.txtCustomerDeleteP);
            this.tabPage4.Controls.Add(this.txtCustomerUpdateV2);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.txtCustomerUpdateP2);
            this.tabPage4.Controls.Add(this.label30);
            this.tabPage4.Controls.Add(this.txtCustomerUpdateV1);
            this.tabPage4.Controls.Add(this.txtCustomerUpdateO);
            this.tabPage4.Controls.Add(this.label31);
            this.tabPage4.Controls.Add(this.txtCustomerUpdateP1);
            this.tabPage4.Controls.Add(this.label32);
            this.tabPage4.Controls.Add(this.label59);
            this.tabPage4.Controls.Add(this.label60);
            this.tabPage4.Controls.Add(this.txtCustomerPhone);
            this.tabPage4.Controls.Add(this.txtCustomerName);
            this.tabPage4.Controls.Add(this.txtCustomerSSN);
            this.tabPage4.Controls.Add(this.btnCustomerRestore);
            this.tabPage4.Controls.Add(this.dataCustomer);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.lblCustomerMessage);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1387, 658);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Customer";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(66, 204);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 17);
            this.label27.TabIndex = 75;
            this.label27.Text = "Address";
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerAddress.Location = new System.Drawing.Point(132, 204);
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(100, 23);
            this.txtCustomerAddress.TabIndex = 74;
            // 
            // btnCustomerDelete
            // 
            this.btnCustomerDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerDelete.Location = new System.Drawing.Point(377, 327);
            this.btnCustomerDelete.Name = "btnCustomerDelete";
            this.btnCustomerDelete.Size = new System.Drawing.Size(77, 29);
            this.btnCustomerDelete.TabIndex = 73;
            this.btnCustomerDelete.Text = "Delete";
            this.btnCustomerDelete.UseVisualStyleBackColor = true;
            this.btnCustomerDelete.Click += new System.EventHandler(this.btnCustomerDelete_Click);
            // 
            // btnCustomerInsert
            // 
            this.btnCustomerInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerInsert.Location = new System.Drawing.Point(112, 252);
            this.btnCustomerInsert.Name = "btnCustomerInsert";
            this.btnCustomerInsert.Size = new System.Drawing.Size(77, 29);
            this.btnCustomerInsert.TabIndex = 72;
            this.btnCustomerInsert.Text = "Insert";
            this.btnCustomerInsert.UseVisualStyleBackColor = true;
            this.btnCustomerInsert.Click += new System.EventHandler(this.btnCustomerInsert_Click);
            // 
            // btnCustomerUpdate
            // 
            this.btnCustomerUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnCustomerUpdate.Name = "btnCustomerUpdate";
            this.btnCustomerUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnCustomerUpdate.TabIndex = 71;
            this.btnCustomerUpdate.Text = "Update";
            this.btnCustomerUpdate.UseVisualStyleBackColor = true;
            this.btnCustomerUpdate.Click += new System.EventHandler(this.btnCustomerUpdate_Click);
            // 
            // txtCustomerDeleteV
            // 
            this.txtCustomerDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerDeleteV.Location = new System.Drawing.Point(444, 283);
            this.txtCustomerDeleteV.Name = "txtCustomerDeleteV";
            this.txtCustomerDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtCustomerDeleteV.TabIndex = 70;
            // 
            // txtCustomerDeleteO
            // 
            this.txtCustomerDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCustomerDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerDeleteO.FormattingEnabled = true;
            this.txtCustomerDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtCustomerDeleteO.Location = new System.Drawing.Point(403, 283);
            this.txtCustomerDeleteO.Name = "txtCustomerDeleteO";
            this.txtCustomerDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtCustomerDeleteO.TabIndex = 69;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(285, 263);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(201, 17);
            this.label28.TabIndex = 68;
            this.label28.Text = "Delete each customer that has";
            // 
            // txtCustomerDeleteP
            // 
            this.txtCustomerDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCustomerDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtCustomerDeleteP.FormattingEnabled = true;
            this.txtCustomerDeleteP.Items.AddRange(new object[] {
            "SSN",
            "NAME",
            "PHONE",
            "ADDRESS"});
            this.txtCustomerDeleteP.Location = new System.Drawing.Point(288, 283);
            this.txtCustomerDeleteP.Name = "txtCustomerDeleteP";
            this.txtCustomerDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtCustomerDeleteP.TabIndex = 67;
            // 
            // txtCustomerUpdateV2
            // 
            this.txtCustomerUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtCustomerUpdateV2.Name = "txtCustomerUpdateV2";
            this.txtCustomerUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtCustomerUpdateV2.TabIndex = 66;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(300, 126);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(117, 17);
            this.label29.TabIndex = 65;
            this.label29.Text = "to this new value:";
            // 
            // txtCustomerUpdateP2
            // 
            this.txtCustomerUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCustomerUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtCustomerUpdateP2.FormattingEnabled = true;
            this.txtCustomerUpdateP2.Items.AddRange(new object[] {
            "SSN",
            "NAME",
            "PHONE",
            "ADDRESS"});
            this.txtCustomerUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtCustomerUpdateP2.Name = "txtCustomerUpdateP2";
            this.txtCustomerUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtCustomerUpdateP2.TabIndex = 64;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(300, 88);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(135, 17);
            this.label30.TabIndex = 63;
            this.label30.Text = "Change the value of";
            // 
            // txtCustomerUpdateV1
            // 
            this.txtCustomerUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtCustomerUpdateV1.Name = "txtCustomerUpdateV1";
            this.txtCustomerUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtCustomerUpdateV1.TabIndex = 62;
            // 
            // txtCustomerUpdateO
            // 
            this.txtCustomerUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCustomerUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerUpdateO.FormattingEnabled = true;
            this.txtCustomerUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtCustomerUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtCustomerUpdateO.Name = "txtCustomerUpdateO";
            this.txtCustomerUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtCustomerUpdateO.TabIndex = 61;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(300, 32);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(181, 17);
            this.label31.TabIndex = 60;
            this.label31.Text = "For each customer that has";
            // 
            // txtCustomerUpdateP1
            // 
            this.txtCustomerUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCustomerUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtCustomerUpdateP1.FormattingEnabled = true;
            this.txtCustomerUpdateP1.Items.AddRange(new object[] {
            "SSN",
            "NAME",
            "PHONE",
            "ADDRESS"});
            this.txtCustomerUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtCustomerUpdateP1.Name = "txtCustomerUpdateP1";
            this.txtCustomerUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtCustomerUpdateP1.TabIndex = 59;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(23, 145);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(103, 17);
            this.label32.TabIndex = 58;
            this.label32.Text = "Phone Number";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(19, 91);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(109, 17);
            this.label59.TabIndex = 57;
            this.label59.Text = "Customer Name";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(26, 37);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(100, 17);
            this.label60.TabIndex = 56;
            this.label60.Text = "Customer SSN";
            // 
            // txtCustomerPhone
            // 
            this.txtCustomerPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerPhone.Location = new System.Drawing.Point(132, 145);
            this.txtCustomerPhone.Name = "txtCustomerPhone";
            this.txtCustomerPhone.Size = new System.Drawing.Size(100, 23);
            this.txtCustomerPhone.TabIndex = 55;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(132, 88);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(100, 23);
            this.txtCustomerName.TabIndex = 54;
            // 
            // txtCustomerSSN
            // 
            this.txtCustomerSSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerSSN.Location = new System.Drawing.Point(132, 34);
            this.txtCustomerSSN.Name = "txtCustomerSSN";
            this.txtCustomerSSN.Size = new System.Drawing.Size(100, 23);
            this.txtCustomerSSN.TabIndex = 53;
            // 
            // btnCustomerRestore
            // 
            this.btnCustomerRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerRestore.Location = new System.Drawing.Point(854, 608);
            this.btnCustomerRestore.Name = "btnCustomerRestore";
            this.btnCustomerRestore.Size = new System.Drawing.Size(255, 39);
            this.btnCustomerRestore.TabIndex = 49;
            this.btnCustomerRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnCustomerRestore.UseVisualStyleBackColor = true;
            this.btnCustomerRestore.Click += new System.EventHandler(this.btnCustomerRestore_Click);
            // 
            // dataCustomer
            // 
            this.dataCustomer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCustomer.Location = new System.Drawing.Point(600, 6);
            this.dataCustomer.Name = "dataCustomer";
            this.dataCustomer.ReadOnly = true;
            this.dataCustomer.Size = new System.Drawing.Size(776, 589);
            this.dataCustomer.TabIndex = 48;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(49, 382);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(122, 17);
            this.label25.TabIndex = 47;
            this.label25.Text = "System Messages";
            // 
            // lblCustomerMessage
            // 
            this.lblCustomerMessage.Location = new System.Drawing.Point(49, 402);
            this.lblCustomerMessage.Name = "lblCustomerMessage";
            this.lblCustomerMessage.ReadOnly = true;
            this.lblCustomerMessage.Size = new System.Drawing.Size(509, 239);
            this.lblCustomerMessage.TabIndex = 46;
            this.lblCustomerMessage.Text = "";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.txtAccountBalance);
            this.tabPage5.Controls.Add(this.btnAccountDelete);
            this.tabPage5.Controls.Add(this.btnAccountInsert);
            this.tabPage5.Controls.Add(this.btnAccountUpdate);
            this.tabPage5.Controls.Add(this.txtAccountDeleteV);
            this.tabPage5.Controls.Add(this.txtAccountDeleteO);
            this.tabPage5.Controls.Add(this.label36);
            this.tabPage5.Controls.Add(this.txtAccountDeleteP);
            this.tabPage5.Controls.Add(this.txtAccountUpdateV2);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Controls.Add(this.txtAccountUpdateP2);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.txtAccountUpdateV1);
            this.tabPage5.Controls.Add(this.txtAccountUpdateO);
            this.tabPage5.Controls.Add(this.label39);
            this.tabPage5.Controls.Add(this.txtAccountUpdateP1);
            this.tabPage5.Controls.Add(this.label40);
            this.tabPage5.Controls.Add(this.label61);
            this.tabPage5.Controls.Add(this.label62);
            this.tabPage5.Controls.Add(this.txtAccountType);
            this.tabPage5.Controls.Add(this.txtAccountSSN);
            this.tabPage5.Controls.Add(this.txtAccountNumber);
            this.tabPage5.Controls.Add(this.btnAccountRestore);
            this.tabPage5.Controls.Add(this.dataAccount);
            this.tabPage5.Controls.Add(this.label33);
            this.tabPage5.Controls.Add(this.lblAccountMessage);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1387, 658);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Account";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(67, 204);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(59, 17);
            this.label35.TabIndex = 75;
            this.label35.Text = "Balance";
            // 
            // txtAccountBalance
            // 
            this.txtAccountBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountBalance.Location = new System.Drawing.Point(132, 204);
            this.txtAccountBalance.Name = "txtAccountBalance";
            this.txtAccountBalance.Size = new System.Drawing.Size(100, 23);
            this.txtAccountBalance.TabIndex = 74;
            // 
            // btnAccountDelete
            // 
            this.btnAccountDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountDelete.Location = new System.Drawing.Point(377, 327);
            this.btnAccountDelete.Name = "btnAccountDelete";
            this.btnAccountDelete.Size = new System.Drawing.Size(77, 29);
            this.btnAccountDelete.TabIndex = 73;
            this.btnAccountDelete.Text = "Delete";
            this.btnAccountDelete.UseVisualStyleBackColor = true;
            this.btnAccountDelete.Click += new System.EventHandler(this.btnAccountDelete_Click);
            // 
            // btnAccountInsert
            // 
            this.btnAccountInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountInsert.Location = new System.Drawing.Point(112, 252);
            this.btnAccountInsert.Name = "btnAccountInsert";
            this.btnAccountInsert.Size = new System.Drawing.Size(77, 29);
            this.btnAccountInsert.TabIndex = 72;
            this.btnAccountInsert.Text = "Insert";
            this.btnAccountInsert.UseVisualStyleBackColor = true;
            this.btnAccountInsert.Click += new System.EventHandler(this.btnAccountInsert_Click);
            // 
            // btnAccountUpdate
            // 
            this.btnAccountUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnAccountUpdate.Name = "btnAccountUpdate";
            this.btnAccountUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnAccountUpdate.TabIndex = 71;
            this.btnAccountUpdate.Text = "Update";
            this.btnAccountUpdate.UseVisualStyleBackColor = true;
            this.btnAccountUpdate.Click += new System.EventHandler(this.btnAccountUpdate_Click);
            // 
            // txtAccountDeleteV
            // 
            this.txtAccountDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountDeleteV.Location = new System.Drawing.Point(444, 283);
            this.txtAccountDeleteV.Name = "txtAccountDeleteV";
            this.txtAccountDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtAccountDeleteV.TabIndex = 70;
            // 
            // txtAccountDeleteO
            // 
            this.txtAccountDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtAccountDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountDeleteO.FormattingEnabled = true;
            this.txtAccountDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtAccountDeleteO.Location = new System.Drawing.Point(403, 283);
            this.txtAccountDeleteO.Name = "txtAccountDeleteO";
            this.txtAccountDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtAccountDeleteO.TabIndex = 69;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(285, 263);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(193, 17);
            this.label36.TabIndex = 68;
            this.label36.Text = "Delete each account that has";
            // 
            // txtAccountDeleteP
            // 
            this.txtAccountDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtAccountDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtAccountDeleteP.FormattingEnabled = true;
            this.txtAccountDeleteP.Items.AddRange(new object[] {
            "ACCOUNTNUMBER",
            "SSN",
            "TYPE",
            "BALANCE"});
            this.txtAccountDeleteP.Location = new System.Drawing.Point(288, 283);
            this.txtAccountDeleteP.Name = "txtAccountDeleteP";
            this.txtAccountDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtAccountDeleteP.TabIndex = 67;
            // 
            // txtAccountUpdateV2
            // 
            this.txtAccountUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtAccountUpdateV2.Name = "txtAccountUpdateV2";
            this.txtAccountUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtAccountUpdateV2.TabIndex = 66;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(300, 126);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(117, 17);
            this.label37.TabIndex = 65;
            this.label37.Text = "to this new value:";
            // 
            // txtAccountUpdateP2
            // 
            this.txtAccountUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtAccountUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtAccountUpdateP2.FormattingEnabled = true;
            this.txtAccountUpdateP2.Items.AddRange(new object[] {
            "ACCOUNTNUMBER",
            "SSN",
            "TYPE",
            "BALANCE"});
            this.txtAccountUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtAccountUpdateP2.Name = "txtAccountUpdateP2";
            this.txtAccountUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtAccountUpdateP2.TabIndex = 64;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(300, 88);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(135, 17);
            this.label38.TabIndex = 63;
            this.label38.Text = "Change the value of";
            // 
            // txtAccountUpdateV1
            // 
            this.txtAccountUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtAccountUpdateV1.Name = "txtAccountUpdateV1";
            this.txtAccountUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtAccountUpdateV1.TabIndex = 62;
            // 
            // txtAccountUpdateO
            // 
            this.txtAccountUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtAccountUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountUpdateO.FormattingEnabled = true;
            this.txtAccountUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtAccountUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtAccountUpdateO.Name = "txtAccountUpdateO";
            this.txtAccountUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtAccountUpdateO.TabIndex = 61;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(300, 32);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(173, 17);
            this.label39.TabIndex = 60;
            this.label39.Text = "For each account that has";
            // 
            // txtAccountUpdateP1
            // 
            this.txtAccountUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtAccountUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtAccountUpdateP1.FormattingEnabled = true;
            this.txtAccountUpdateP1.Items.AddRange(new object[] {
            "ACCOUNTNUMBER",
            "SSN",
            "TYPE",
            "BALANCE"});
            this.txtAccountUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtAccountUpdateP1.Name = "txtAccountUpdateP1";
            this.txtAccountUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtAccountUpdateP1.TabIndex = 59;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(31, 145);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 17);
            this.label40.TabIndex = 58;
            this.label40.Text = "Account Type";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(26, 88);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(100, 17);
            this.label61.TabIndex = 57;
            this.label61.Text = "Customer SSN";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(13, 37);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(113, 17);
            this.label62.TabIndex = 56;
            this.label62.Text = "Account Number";
            // 
            // txtAccountType
            // 
            this.txtAccountType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountType.Location = new System.Drawing.Point(132, 145);
            this.txtAccountType.Name = "txtAccountType";
            this.txtAccountType.Size = new System.Drawing.Size(100, 23);
            this.txtAccountType.TabIndex = 55;
            // 
            // txtAccountSSN
            // 
            this.txtAccountSSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountSSN.Location = new System.Drawing.Point(132, 88);
            this.txtAccountSSN.Name = "txtAccountSSN";
            this.txtAccountSSN.Size = new System.Drawing.Size(100, 23);
            this.txtAccountSSN.TabIndex = 54;
            // 
            // txtAccountNumber
            // 
            this.txtAccountNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNumber.Location = new System.Drawing.Point(132, 34);
            this.txtAccountNumber.Name = "txtAccountNumber";
            this.txtAccountNumber.Size = new System.Drawing.Size(100, 23);
            this.txtAccountNumber.TabIndex = 53;
            // 
            // btnAccountRestore
            // 
            this.btnAccountRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountRestore.Location = new System.Drawing.Point(854, 608);
            this.btnAccountRestore.Name = "btnAccountRestore";
            this.btnAccountRestore.Size = new System.Drawing.Size(255, 39);
            this.btnAccountRestore.TabIndex = 49;
            this.btnAccountRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnAccountRestore.UseVisualStyleBackColor = true;
            this.btnAccountRestore.Click += new System.EventHandler(this.btnAccountRestore_Click);
            // 
            // dataAccount
            // 
            this.dataAccount.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataAccount.Location = new System.Drawing.Point(600, 6);
            this.dataAccount.Name = "dataAccount";
            this.dataAccount.ReadOnly = true;
            this.dataAccount.Size = new System.Drawing.Size(776, 589);
            this.dataAccount.TabIndex = 48;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(49, 382);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(122, 17);
            this.label33.TabIndex = 47;
            this.label33.Text = "System Messages";
            // 
            // lblAccountMessage
            // 
            this.lblAccountMessage.Location = new System.Drawing.Point(49, 402);
            this.lblAccountMessage.Name = "lblAccountMessage";
            this.lblAccountMessage.ReadOnly = true;
            this.lblAccountMessage.Size = new System.Drawing.Size(509, 239);
            this.lblAccountMessage.TabIndex = 46;
            this.lblAccountMessage.Text = "";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label63);
            this.tabPage6.Controls.Add(this.label64);
            this.tabPage6.Controls.Add(this.label65);
            this.tabPage6.Controls.Add(this.txtBorrowsStartDate);
            this.tabPage6.Controls.Add(this.txtBorrowsAmount);
            this.tabPage6.Controls.Add(this.txtBorrowsSSN);
            this.tabPage6.Controls.Add(this.btnBorrowRestore);
            this.tabPage6.Controls.Add(this.dataBorrows);
            this.tabPage6.Controls.Add(this.label41);
            this.tabPage6.Controls.Add(this.lblBorrowsMessage);
            this.tabPage6.Controls.Add(this.btnBorrowsDelete);
            this.tabPage6.Controls.Add(this.btnBorrowsInsert);
            this.tabPage6.Controls.Add(this.btnBorrowsUpdate);
            this.tabPage6.Controls.Add(this.txtBorrowsDeleteV);
            this.tabPage6.Controls.Add(this.txtBorrowsDeleteO);
            this.tabPage6.Controls.Add(this.label42);
            this.tabPage6.Controls.Add(this.txtBorrowsDeleteP);
            this.tabPage6.Controls.Add(this.txtBorrowsUpdateV2);
            this.tabPage6.Controls.Add(this.label43);
            this.tabPage6.Controls.Add(this.txtBorrowsUpdateP2);
            this.tabPage6.Controls.Add(this.label44);
            this.tabPage6.Controls.Add(this.txtBorrowsUpdateV1);
            this.tabPage6.Controls.Add(this.txtBorrowsUpdateO);
            this.tabPage6.Controls.Add(this.label45);
            this.tabPage6.Controls.Add(this.txtBorrowsUpdateP1);
            this.tabPage6.Controls.Add(this.label46);
            this.tabPage6.Controls.Add(this.label47);
            this.tabPage6.Controls.Add(this.label48);
            this.tabPage6.Controls.Add(this.txtBorrowsLoanNumber);
            this.tabPage6.Controls.Add(this.txtBorrowsBranchNumber);
            this.tabPage6.Controls.Add(this.txtBorrowsBankCode);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1387, 658);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Borrows";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(18, 281);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(108, 17);
            this.label63.TabIndex = 55;
            this.label63.Text = "Loan Start Date";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(34, 233);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(92, 17);
            this.label64.TabIndex = 54;
            this.label64.Text = "Loan Amount";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(26, 183);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(100, 17);
            this.label65.TabIndex = 53;
            this.label65.Text = "Customer SSN";
            // 
            // txtBorrowsStartDate
            // 
            this.txtBorrowsStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsStartDate.Location = new System.Drawing.Point(132, 278);
            this.txtBorrowsStartDate.Name = "txtBorrowsStartDate";
            this.txtBorrowsStartDate.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsStartDate.TabIndex = 52;
            // 
            // txtBorrowsAmount
            // 
            this.txtBorrowsAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsAmount.Location = new System.Drawing.Point(132, 230);
            this.txtBorrowsAmount.Name = "txtBorrowsAmount";
            this.txtBorrowsAmount.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsAmount.TabIndex = 51;
            // 
            // txtBorrowsSSN
            // 
            this.txtBorrowsSSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsSSN.Location = new System.Drawing.Point(132, 180);
            this.txtBorrowsSSN.Name = "txtBorrowsSSN";
            this.txtBorrowsSSN.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsSSN.TabIndex = 50;
            // 
            // btnBorrowRestore
            // 
            this.btnBorrowRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrowRestore.Location = new System.Drawing.Point(854, 608);
            this.btnBorrowRestore.Name = "btnBorrowRestore";
            this.btnBorrowRestore.Size = new System.Drawing.Size(255, 39);
            this.btnBorrowRestore.TabIndex = 49;
            this.btnBorrowRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnBorrowRestore.UseVisualStyleBackColor = true;
            this.btnBorrowRestore.Click += new System.EventHandler(this.btnBorrowRestore_Click);
            // 
            // dataBorrows
            // 
            this.dataBorrows.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataBorrows.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataBorrows.Location = new System.Drawing.Point(600, 6);
            this.dataBorrows.Name = "dataBorrows";
            this.dataBorrows.ReadOnly = true;
            this.dataBorrows.Size = new System.Drawing.Size(776, 589);
            this.dataBorrows.TabIndex = 48;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(49, 382);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(122, 17);
            this.label41.TabIndex = 47;
            this.label41.Text = "System Messages";
            // 
            // lblBorrowsMessage
            // 
            this.lblBorrowsMessage.Location = new System.Drawing.Point(49, 402);
            this.lblBorrowsMessage.Name = "lblBorrowsMessage";
            this.lblBorrowsMessage.ReadOnly = true;
            this.lblBorrowsMessage.Size = new System.Drawing.Size(509, 239);
            this.lblBorrowsMessage.TabIndex = 46;
            this.lblBorrowsMessage.Text = "";
            // 
            // btnBorrowsDelete
            // 
            this.btnBorrowsDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrowsDelete.Location = new System.Drawing.Point(377, 327);
            this.btnBorrowsDelete.Name = "btnBorrowsDelete";
            this.btnBorrowsDelete.Size = new System.Drawing.Size(77, 29);
            this.btnBorrowsDelete.TabIndex = 45;
            this.btnBorrowsDelete.Text = "Delete";
            this.btnBorrowsDelete.UseVisualStyleBackColor = true;
            this.btnBorrowsDelete.Click += new System.EventHandler(this.btnBorrowsDelete_Click);
            // 
            // btnBorrowsInsert
            // 
            this.btnBorrowsInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrowsInsert.Location = new System.Drawing.Point(107, 324);
            this.btnBorrowsInsert.Name = "btnBorrowsInsert";
            this.btnBorrowsInsert.Size = new System.Drawing.Size(77, 29);
            this.btnBorrowsInsert.TabIndex = 44;
            this.btnBorrowsInsert.Text = "Insert";
            this.btnBorrowsInsert.UseVisualStyleBackColor = true;
            this.btnBorrowsInsert.Click += new System.EventHandler(this.btnBorrowsInsert_Click);
            // 
            // btnBorrowsUpdate
            // 
            this.btnBorrowsUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrowsUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnBorrowsUpdate.Name = "btnBorrowsUpdate";
            this.btnBorrowsUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnBorrowsUpdate.TabIndex = 43;
            this.btnBorrowsUpdate.Text = "Update";
            this.btnBorrowsUpdate.UseVisualStyleBackColor = true;
            this.btnBorrowsUpdate.Click += new System.EventHandler(this.btnBorrowsUpdate_Click);
            // 
            // txtBorrowsDeleteV
            // 
            this.txtBorrowsDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsDeleteV.Location = new System.Drawing.Point(444, 283);
            this.txtBorrowsDeleteV.Name = "txtBorrowsDeleteV";
            this.txtBorrowsDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsDeleteV.TabIndex = 42;
            // 
            // txtBorrowsDeleteO
            // 
            this.txtBorrowsDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBorrowsDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsDeleteO.FormattingEnabled = true;
            this.txtBorrowsDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtBorrowsDeleteO.Location = new System.Drawing.Point(403, 283);
            this.txtBorrowsDeleteO.Name = "txtBorrowsDeleteO";
            this.txtBorrowsDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtBorrowsDeleteO.TabIndex = 41;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(285, 263);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(233, 17);
            this.label42.TabIndex = 40;
            this.label42.Text = "Delete each borrowed loan that has";
            // 
            // txtBorrowsDeleteP
            // 
            this.txtBorrowsDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBorrowsDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBorrowsDeleteP.FormattingEnabled = true;
            this.txtBorrowsDeleteP.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "LOANNUMBER",
            "SSN",
            "AMOUNT",
            "START_DATE"});
            this.txtBorrowsDeleteP.Location = new System.Drawing.Point(288, 283);
            this.txtBorrowsDeleteP.Name = "txtBorrowsDeleteP";
            this.txtBorrowsDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtBorrowsDeleteP.TabIndex = 39;
            // 
            // txtBorrowsUpdateV2
            // 
            this.txtBorrowsUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtBorrowsUpdateV2.Name = "txtBorrowsUpdateV2";
            this.txtBorrowsUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtBorrowsUpdateV2.TabIndex = 38;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(300, 126);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(117, 17);
            this.label43.TabIndex = 37;
            this.label43.Text = "to this new value:";
            // 
            // txtBorrowsUpdateP2
            // 
            this.txtBorrowsUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBorrowsUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBorrowsUpdateP2.FormattingEnabled = true;
            this.txtBorrowsUpdateP2.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "LOANNUMBER",
            "SSN",
            "AMOUNT",
            "START_DATE"});
            this.txtBorrowsUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtBorrowsUpdateP2.Name = "txtBorrowsUpdateP2";
            this.txtBorrowsUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtBorrowsUpdateP2.TabIndex = 36;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(300, 88);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(135, 17);
            this.label44.TabIndex = 35;
            this.label44.Text = "Change the value of";
            // 
            // txtBorrowsUpdateV1
            // 
            this.txtBorrowsUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtBorrowsUpdateV1.Name = "txtBorrowsUpdateV1";
            this.txtBorrowsUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsUpdateV1.TabIndex = 34;
            // 
            // txtBorrowsUpdateO
            // 
            this.txtBorrowsUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBorrowsUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsUpdateO.FormattingEnabled = true;
            this.txtBorrowsUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtBorrowsUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtBorrowsUpdateO.Name = "txtBorrowsUpdateO";
            this.txtBorrowsUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtBorrowsUpdateO.TabIndex = 33;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(300, 32);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(213, 17);
            this.label45.TabIndex = 32;
            this.label45.Text = "For each borrowed loan that has";
            // 
            // txtBorrowsUpdateP1
            // 
            this.txtBorrowsUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBorrowsUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtBorrowsUpdateP1.FormattingEnabled = true;
            this.txtBorrowsUpdateP1.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "LOANNUMBER",
            "SSN",
            "AMOUNT",
            "START_DATE"});
            this.txtBorrowsUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtBorrowsUpdateP1.Name = "txtBorrowsUpdateP1";
            this.txtBorrowsUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtBorrowsUpdateP1.TabIndex = 31;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(32, 129);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(94, 17);
            this.label46.TabIndex = 30;
            this.label46.Text = "Loan Number";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(19, 83);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(107, 17);
            this.label47.TabIndex = 29;
            this.label47.Text = "Branch Number";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(49, 37);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(77, 17);
            this.label48.TabIndex = 28;
            this.label48.Text = "Bank Code";
            // 
            // txtBorrowsLoanNumber
            // 
            this.txtBorrowsLoanNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsLoanNumber.Location = new System.Drawing.Point(132, 131);
            this.txtBorrowsLoanNumber.Name = "txtBorrowsLoanNumber";
            this.txtBorrowsLoanNumber.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsLoanNumber.TabIndex = 27;
            // 
            // txtBorrowsBranchNumber
            // 
            this.txtBorrowsBranchNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsBranchNumber.Location = new System.Drawing.Point(132, 80);
            this.txtBorrowsBranchNumber.Name = "txtBorrowsBranchNumber";
            this.txtBorrowsBranchNumber.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsBranchNumber.TabIndex = 26;
            // 
            // txtBorrowsBankCode
            // 
            this.txtBorrowsBankCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowsBankCode.Location = new System.Drawing.Point(132, 34);
            this.txtBorrowsBankCode.Name = "txtBorrowsBankCode";
            this.txtBorrowsBankCode.Size = new System.Drawing.Size(100, 23);
            this.txtBorrowsBankCode.TabIndex = 25;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.btnHasRestore);
            this.tabPage7.Controls.Add(this.dataHas);
            this.tabPage7.Controls.Add(this.label49);
            this.tabPage7.Controls.Add(this.lblHasMessage);
            this.tabPage7.Controls.Add(this.btnHasDelete);
            this.tabPage7.Controls.Add(this.btnHasInsert);
            this.tabPage7.Controls.Add(this.btnHasUpdate);
            this.tabPage7.Controls.Add(this.txtHasDeleteV);
            this.tabPage7.Controls.Add(this.txtHasDeleteO);
            this.tabPage7.Controls.Add(this.label50);
            this.tabPage7.Controls.Add(this.txtHasDeleteP);
            this.tabPage7.Controls.Add(this.txtHasUpdateV2);
            this.tabPage7.Controls.Add(this.label51);
            this.tabPage7.Controls.Add(this.txtHasUpdateP2);
            this.tabPage7.Controls.Add(this.label52);
            this.tabPage7.Controls.Add(this.txtHasUpdateV1);
            this.tabPage7.Controls.Add(this.txtHasUpdateO);
            this.tabPage7.Controls.Add(this.label53);
            this.tabPage7.Controls.Add(this.txtHasUpdateP1);
            this.tabPage7.Controls.Add(this.label54);
            this.tabPage7.Controls.Add(this.label55);
            this.tabPage7.Controls.Add(this.label56);
            this.tabPage7.Controls.Add(this.txtHasSSN);
            this.tabPage7.Controls.Add(this.txtHasBranchNumber);
            this.tabPage7.Controls.Add(this.txtHasBankCode);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1387, 658);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Has";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // btnHasRestore
            // 
            this.btnHasRestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHasRestore.Location = new System.Drawing.Point(854, 608);
            this.btnHasRestore.Name = "btnHasRestore";
            this.btnHasRestore.Size = new System.Drawing.Size(255, 39);
            this.btnHasRestore.TabIndex = 49;
            this.btnHasRestore.Text = "RESTORE ORIGINAL DATA";
            this.btnHasRestore.UseVisualStyleBackColor = true;
            this.btnHasRestore.Click += new System.EventHandler(this.btnHasRestore_Click);
            // 
            // dataHas
            // 
            this.dataHas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataHas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataHas.Location = new System.Drawing.Point(600, 6);
            this.dataHas.Name = "dataHas";
            this.dataHas.ReadOnly = true;
            this.dataHas.Size = new System.Drawing.Size(776, 589);
            this.dataHas.TabIndex = 48;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(49, 382);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(122, 17);
            this.label49.TabIndex = 47;
            this.label49.Text = "System Messages";
            // 
            // lblHasMessage
            // 
            this.lblHasMessage.Location = new System.Drawing.Point(49, 402);
            this.lblHasMessage.Name = "lblHasMessage";
            this.lblHasMessage.ReadOnly = true;
            this.lblHasMessage.Size = new System.Drawing.Size(509, 239);
            this.lblHasMessage.TabIndex = 46;
            this.lblHasMessage.Text = "";
            // 
            // btnHasDelete
            // 
            this.btnHasDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHasDelete.Location = new System.Drawing.Point(234, 326);
            this.btnHasDelete.Name = "btnHasDelete";
            this.btnHasDelete.Size = new System.Drawing.Size(77, 29);
            this.btnHasDelete.TabIndex = 45;
            this.btnHasDelete.Text = "Delete";
            this.btnHasDelete.UseVisualStyleBackColor = true;
            this.btnHasDelete.Click += new System.EventHandler(this.btnHasDelete_Click);
            // 
            // btnHasInsert
            // 
            this.btnHasInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHasInsert.Location = new System.Drawing.Point(113, 176);
            this.btnHasInsert.Name = "btnHasInsert";
            this.btnHasInsert.Size = new System.Drawing.Size(77, 29);
            this.btnHasInsert.TabIndex = 44;
            this.btnHasInsert.Text = "Insert";
            this.btnHasInsert.UseVisualStyleBackColor = true;
            this.btnHasInsert.Click += new System.EventHandler(this.btnHasInsert_Click);
            // 
            // btnHasUpdate
            // 
            this.btnHasUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHasUpdate.Location = new System.Drawing.Point(377, 176);
            this.btnHasUpdate.Name = "btnHasUpdate";
            this.btnHasUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnHasUpdate.TabIndex = 43;
            this.btnHasUpdate.Text = "Update";
            this.btnHasUpdate.UseVisualStyleBackColor = true;
            this.btnHasUpdate.Click += new System.EventHandler(this.btnHasUpdate_Click);
            // 
            // txtHasDeleteV
            // 
            this.txtHasDeleteV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasDeleteV.Location = new System.Drawing.Point(301, 282);
            this.txtHasDeleteV.Name = "txtHasDeleteV";
            this.txtHasDeleteV.Size = new System.Drawing.Size(100, 23);
            this.txtHasDeleteV.TabIndex = 42;
            // 
            // txtHasDeleteO
            // 
            this.txtHasDeleteO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtHasDeleteO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasDeleteO.FormattingEnabled = true;
            this.txtHasDeleteO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtHasDeleteO.Location = new System.Drawing.Point(260, 282);
            this.txtHasDeleteO.Name = "txtHasDeleteO";
            this.txtHasDeleteO.Size = new System.Drawing.Size(35, 24);
            this.txtHasDeleteO.TabIndex = 41;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(142, 262);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(184, 17);
            this.label50.TabIndex = 40;
            this.label50.Text = "Delete each record that has";
            // 
            // txtHasDeleteP
            // 
            this.txtHasDeleteP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtHasDeleteP.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtHasDeleteP.FormattingEnabled = true;
            this.txtHasDeleteP.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "SSN"});
            this.txtHasDeleteP.Location = new System.Drawing.Point(145, 282);
            this.txtHasDeleteP.Name = "txtHasDeleteP";
            this.txtHasDeleteP.Size = new System.Drawing.Size(109, 24);
            this.txtHasDeleteP.TabIndex = 39;
            // 
            // txtHasUpdateV2
            // 
            this.txtHasUpdateV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasUpdateV2.Location = new System.Drawing.Point(419, 126);
            this.txtHasUpdateV2.Name = "txtHasUpdateV2";
            this.txtHasUpdateV2.Size = new System.Drawing.Size(139, 23);
            this.txtHasUpdateV2.TabIndex = 38;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(300, 126);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(117, 17);
            this.label51.TabIndex = 37;
            this.label51.Text = "to this new value:";
            // 
            // txtHasUpdateP2
            // 
            this.txtHasUpdateP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtHasUpdateP2.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtHasUpdateP2.FormattingEnabled = true;
            this.txtHasUpdateP2.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "SSN"});
            this.txtHasUpdateP2.Location = new System.Drawing.Point(439, 85);
            this.txtHasUpdateP2.Name = "txtHasUpdateP2";
            this.txtHasUpdateP2.Size = new System.Drawing.Size(119, 24);
            this.txtHasUpdateP2.TabIndex = 36;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(300, 88);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(135, 17);
            this.label52.TabIndex = 35;
            this.label52.Text = "Change the value of";
            // 
            // txtHasUpdateV1
            // 
            this.txtHasUpdateV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasUpdateV1.Location = new System.Drawing.Point(458, 52);
            this.txtHasUpdateV1.Name = "txtHasUpdateV1";
            this.txtHasUpdateV1.Size = new System.Drawing.Size(100, 23);
            this.txtHasUpdateV1.TabIndex = 34;
            // 
            // txtHasUpdateO
            // 
            this.txtHasUpdateO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtHasUpdateO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasUpdateO.FormattingEnabled = true;
            this.txtHasUpdateO.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.txtHasUpdateO.Location = new System.Drawing.Point(417, 52);
            this.txtHasUpdateO.Name = "txtHasUpdateO";
            this.txtHasUpdateO.Size = new System.Drawing.Size(35, 24);
            this.txtHasUpdateO.TabIndex = 33;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(300, 32);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(164, 17);
            this.label53.TabIndex = 32;
            this.label53.Text = "For each record that has";
            // 
            // txtHasUpdateP1
            // 
            this.txtHasUpdateP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtHasUpdateP1.Font = new System.Drawing.Font("Bahnschrift SemiLight SemiConde", 9.5F);
            this.txtHasUpdateP1.FormattingEnabled = true;
            this.txtHasUpdateP1.Items.AddRange(new object[] {
            "BANKCODE",
            "BRANCHNUMBER",
            "SSN"});
            this.txtHasUpdateP1.Location = new System.Drawing.Point(301, 52);
            this.txtHasUpdateP1.Name = "txtHasUpdateP1";
            this.txtHasUpdateP1.Size = new System.Drawing.Size(110, 24);
            this.txtHasUpdateP1.TabIndex = 31;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(26, 129);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(100, 17);
            this.label54.TabIndex = 30;
            this.label54.Text = "Customer SSN";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(19, 82);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(107, 17);
            this.label55.TabIndex = 29;
            this.label55.Text = "Branch Number";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(49, 37);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(77, 17);
            this.label56.TabIndex = 28;
            this.label56.Text = "Bank Code";
            // 
            // txtHasSSN
            // 
            this.txtHasSSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasSSN.Location = new System.Drawing.Point(132, 129);
            this.txtHasSSN.Name = "txtHasSSN";
            this.txtHasSSN.Size = new System.Drawing.Size(100, 23);
            this.txtHasSSN.TabIndex = 27;
            // 
            // txtHasBranchNumber
            // 
            this.txtHasBranchNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasBranchNumber.Location = new System.Drawing.Point(132, 79);
            this.txtHasBranchNumber.Name = "txtHasBranchNumber";
            this.txtHasBranchNumber.Size = new System.Drawing.Size(100, 23);
            this.txtHasBranchNumber.TabIndex = 26;
            // 
            // txtHasBankCode
            // 
            this.txtHasBankCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHasBankCode.Location = new System.Drawing.Point(132, 34);
            this.txtHasBankCode.Name = "txtHasBankCode";
            this.txtHasBankCode.Size = new System.Drawing.Size(100, 23);
            this.txtHasBankCode.TabIndex = 25;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.btnReportsHighestLoans);
            this.tabPage8.Controls.Add(this.btnReportsEarliestLoans);
            this.tabPage8.Controls.Add(this.btnReportsTotalLoan);
            this.tabPage8.Controls.Add(this.btnReportsNumOfCustomers);
            this.tabPage8.Controls.Add(this.btnReportsRichestCustomers);
            this.tabPage8.Controls.Add(this.btnReportsMostBorrowed);
            this.tabPage8.Controls.Add(this.dataReports);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1387, 658);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "REPORTS";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // btnReportsHighestLoans
            // 
            this.btnReportsHighestLoans.Location = new System.Drawing.Point(56, 251);
            this.btnReportsHighestLoans.Name = "btnReportsHighestLoans";
            this.btnReportsHighestLoans.Size = new System.Drawing.Size(183, 58);
            this.btnReportsHighestLoans.TabIndex = 6;
            this.btnReportsHighestLoans.Text = "Set of loans of the highest value in each branch";
            this.btnReportsHighestLoans.UseVisualStyleBackColor = true;
            this.btnReportsHighestLoans.Click += new System.EventHandler(this.btnReportsHighestLoans_Click);
            // 
            // btnReportsEarliestLoans
            // 
            this.btnReportsEarliestLoans.Location = new System.Drawing.Point(56, 383);
            this.btnReportsEarliestLoans.Name = "btnReportsEarliestLoans";
            this.btnReportsEarliestLoans.Size = new System.Drawing.Size(183, 59);
            this.btnReportsEarliestLoans.TabIndex = 5;
            this.btnReportsEarliestLoans.Text = "Earliest set of loans in each branch";
            this.btnReportsEarliestLoans.UseVisualStyleBackColor = true;
            this.btnReportsEarliestLoans.Click += new System.EventHandler(this.btnReportsEarliestLoans_Click);
            // 
            // btnReportsTotalLoan
            // 
            this.btnReportsTotalLoan.Location = new System.Drawing.Point(311, 383);
            this.btnReportsTotalLoan.Name = "btnReportsTotalLoan";
            this.btnReportsTotalLoan.Size = new System.Drawing.Size(183, 59);
            this.btnReportsTotalLoan.TabIndex = 4;
            this.btnReportsTotalLoan.Text = "Customers\' total loaned amount across all loans";
            this.btnReportsTotalLoan.UseVisualStyleBackColor = true;
            this.btnReportsTotalLoan.Click += new System.EventHandler(this.btnReportsTotalLoan_Click);
            // 
            // btnReportsNumOfCustomers
            // 
            this.btnReportsNumOfCustomers.Location = new System.Drawing.Point(311, 250);
            this.btnReportsNumOfCustomers.Name = "btnReportsNumOfCustomers";
            this.btnReportsNumOfCustomers.Size = new System.Drawing.Size(183, 59);
            this.btnReportsNumOfCustomers.TabIndex = 3;
            this.btnReportsNumOfCustomers.Text = "Number of customers in each branch";
            this.btnReportsNumOfCustomers.UseVisualStyleBackColor = true;
            this.btnReportsNumOfCustomers.Click += new System.EventHandler(this.btnReportsNumOfCustomers_Click);
            // 
            // btnReportsRichestCustomers
            // 
            this.btnReportsRichestCustomers.Location = new System.Drawing.Point(56, 115);
            this.btnReportsRichestCustomers.Name = "btnReportsRichestCustomers";
            this.btnReportsRichestCustomers.Size = new System.Drawing.Size(183, 58);
            this.btnReportsRichestCustomers.TabIndex = 2;
            this.btnReportsRichestCustomers.Text = "Customers\' total balance across all accounts";
            this.btnReportsRichestCustomers.UseVisualStyleBackColor = true;
            this.btnReportsRichestCustomers.Click += new System.EventHandler(this.btnReportsRichestCustomers_Click);
            // 
            // btnReportsMostBorrowed
            // 
            this.btnReportsMostBorrowed.Location = new System.Drawing.Point(311, 115);
            this.btnReportsMostBorrowed.Name = "btnReportsMostBorrowed";
            this.btnReportsMostBorrowed.Size = new System.Drawing.Size(183, 58);
            this.btnReportsMostBorrowed.TabIndex = 1;
            this.btnReportsMostBorrowed.Text = "All loans ordered by number of borrowers";
            this.btnReportsMostBorrowed.UseVisualStyleBackColor = true;
            this.btnReportsMostBorrowed.Click += new System.EventHandler(this.btnReportsMostBorrowed_Click);
            // 
            // dataReports
            // 
            this.dataReports.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataReports.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataReports.Location = new System.Drawing.Point(587, 6);
            this.dataReports.Name = "dataReports";
            this.dataReports.ReadOnly = true;
            this.dataReports.Size = new System.Drawing.Size(789, 644);
            this.dataReports.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1392, 687);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximumSize = new System.Drawing.Size(1408, 726);
            this.MinimumSize = new System.Drawing.Size(1408, 726);
            this.Name = "Form1";
            this.Text = "Bank System";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBank)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBranch)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataLoan)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCustomer)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataAccount)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBorrows)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataHas)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataReports)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBankAddress;
        private System.Windows.Forms.TextBox txtBankBankName;
        private System.Windows.Forms.TextBox txtBankBankCode;
        private System.Windows.Forms.ComboBox txtBankUpdateP1;
        private System.Windows.Forms.ComboBox txtBankUpdateO;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBankUpdateV2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox txtBankUpdateP2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBankUpdateV1;
        private System.Windows.Forms.TextBox txtBankDeleteV;
        private System.Windows.Forms.ComboBox txtBankDeleteO;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox txtBankDeleteP;
        private System.Windows.Forms.DataGridView dataBank;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox lblBankMessage;
        private System.Windows.Forms.Button btnBankDelete;
        private System.Windows.Forms.Button btnBankInsert;
        private System.Windows.Forms.Button btnBankUpdate;
        private System.Windows.Forms.Button btnBankRestore;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button btnReportsMostBorrowed;
        private System.Windows.Forms.DataGridView dataReports;
        private System.Windows.Forms.Button btnReportsRichestCustomers;
        private System.Windows.Forms.Button btnReportsNumOfCustomers;
        private System.Windows.Forms.Button btnReportsTotalLoan;
        private System.Windows.Forms.Button btnBranchRestore;
        private System.Windows.Forms.DataGridView dataBranch;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox lblBranchMessage;
        private System.Windows.Forms.Button btnBranchDelete;
        private System.Windows.Forms.Button btnBranchInsert;
        private System.Windows.Forms.Button btnBranchUpdate;
        private System.Windows.Forms.TextBox txtBranchDeleteV;
        private System.Windows.Forms.ComboBox txtBranchDeleteO;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox txtBranchDeleteP;
        private System.Windows.Forms.TextBox txtBranchUpdateV2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox txtBranchUpdateP2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBranchUpdateV1;
        private System.Windows.Forms.ComboBox txtBranchUpdateO;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox txtBranchUpdateP1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtBranchAddress;
        private System.Windows.Forms.TextBox txtBranchBranchNumber;
        private System.Windows.Forms.TextBox txtBranchBankCode;
        private System.Windows.Forms.Button btnLoanRestore;
        private System.Windows.Forms.DataGridView dataLoan;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox lblLoanMessage;
        private System.Windows.Forms.Button btnLoanDelete;
        private System.Windows.Forms.Button btnLoanInsert;
        private System.Windows.Forms.Button btnLoanUpdate;
        private System.Windows.Forms.TextBox txtLoanDeleteV;
        private System.Windows.Forms.ComboBox txtLoanDeleteO;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox txtLoanDeleteP;
        private System.Windows.Forms.TextBox txtLoanUpdateV2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox txtLoanUpdateP2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtLoanUpdateV1;
        private System.Windows.Forms.ComboBox txtLoanUpdateO;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox txtLoanUpdateP1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtLoanLoanNumber;
        private System.Windows.Forms.TextBox txtLoanBranchNumber;
        private System.Windows.Forms.TextBox txtLoanBankCode;
        private System.Windows.Forms.Button btnCustomerRestore;
        private System.Windows.Forms.DataGridView dataCustomer;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RichTextBox lblCustomerMessage;
        private System.Windows.Forms.Button btnAccountRestore;
        private System.Windows.Forms.DataGridView dataAccount;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RichTextBox lblAccountMessage;
        private System.Windows.Forms.Button btnBorrowRestore;
        private System.Windows.Forms.DataGridView dataBorrows;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.RichTextBox lblBorrowsMessage;
        private System.Windows.Forms.Button btnBorrowsDelete;
        private System.Windows.Forms.Button btnBorrowsInsert;
        private System.Windows.Forms.Button btnBorrowsUpdate;
        private System.Windows.Forms.TextBox txtBorrowsDeleteV;
        private System.Windows.Forms.ComboBox txtBorrowsDeleteO;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox txtBorrowsDeleteP;
        private System.Windows.Forms.TextBox txtBorrowsUpdateV2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox txtBorrowsUpdateP2;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtBorrowsUpdateV1;
        private System.Windows.Forms.ComboBox txtBorrowsUpdateO;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox txtBorrowsUpdateP1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtBorrowsLoanNumber;
        private System.Windows.Forms.TextBox txtBorrowsBranchNumber;
        private System.Windows.Forms.TextBox txtBorrowsBankCode;
        private System.Windows.Forms.Button btnHasRestore;
        private System.Windows.Forms.DataGridView dataHas;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RichTextBox lblHasMessage;
        private System.Windows.Forms.Button btnHasDelete;
        private System.Windows.Forms.Button btnHasInsert;
        private System.Windows.Forms.Button btnHasUpdate;
        private System.Windows.Forms.TextBox txtHasDeleteV;
        private System.Windows.Forms.ComboBox txtHasDeleteO;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox txtHasDeleteP;
        private System.Windows.Forms.TextBox txtHasUpdateV2;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox txtHasUpdateP2;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtHasUpdateV1;
        private System.Windows.Forms.ComboBox txtHasUpdateO;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ComboBox txtHasUpdateP1;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtHasSSN;
        private System.Windows.Forms.TextBox txtHasBranchNumber;
        private System.Windows.Forms.TextBox txtHasBankCode;
        private System.Windows.Forms.Button btnReportsHighestLoans;
        private System.Windows.Forms.Button btnReportsEarliestLoans;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtLoanLoanType;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.Button btnCustomerDelete;
        private System.Windows.Forms.Button btnCustomerInsert;
        private System.Windows.Forms.Button btnCustomerUpdate;
        private System.Windows.Forms.TextBox txtCustomerDeleteV;
        private System.Windows.Forms.ComboBox txtCustomerDeleteO;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox txtCustomerDeleteP;
        private System.Windows.Forms.TextBox txtCustomerUpdateV2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox txtCustomerUpdateP2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtCustomerUpdateV1;
        private System.Windows.Forms.ComboBox txtCustomerUpdateO;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox txtCustomerUpdateP1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtCustomerPhone;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtCustomerSSN;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtAccountBalance;
        private System.Windows.Forms.Button btnAccountDelete;
        private System.Windows.Forms.Button btnAccountInsert;
        private System.Windows.Forms.Button btnAccountUpdate;
        private System.Windows.Forms.TextBox txtAccountDeleteV;
        private System.Windows.Forms.ComboBox txtAccountDeleteO;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox txtAccountDeleteP;
        private System.Windows.Forms.TextBox txtAccountUpdateV2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox txtAccountUpdateP2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtAccountUpdateV1;
        private System.Windows.Forms.ComboBox txtAccountUpdateO;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox txtAccountUpdateP1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtAccountType;
        private System.Windows.Forms.TextBox txtAccountSSN;
        private System.Windows.Forms.TextBox txtAccountNumber;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtBorrowsStartDate;
        private System.Windows.Forms.TextBox txtBorrowsAmount;
        private System.Windows.Forms.TextBox txtBorrowsSSN;
    }
}

